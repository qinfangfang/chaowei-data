const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  lintOnSave:false, // 关闭eslint语法检查
  transpileDependencies: true,
});
